import React from 'react'

export default function Monthly(){
  return (
    <div>
      <h1 className="text-3xl font-bold">Visão Mensal</h1>
      <p className="mt-4 card p-4">Resumo mensal do clima.</p>
    </div>
  )
}

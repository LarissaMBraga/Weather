import React from 'react'

export default function Days(){
  return (
    <div>
      <h1 className="text-3xl font-bold">Previsão por dias</h1>
      <p className="mt-4 card p-4">Aqui estarão os cards de previsão diária (implementados similarmente ao app Expo).</p>
    </div>
  )
}

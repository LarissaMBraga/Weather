# Weather Web (converted)

Projeto convertido para **React + TypeScript + Tailwind + Vite**.
API do OpenWeather já configurada (key incluida em código).

## Rodar localmente
```bash
npm install
npm run dev
```

## Importar no CodeSandbox
Importe o arquivo ZIP gerado direto no CodeSandbox.


